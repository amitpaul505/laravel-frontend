@extends('layouts.app')
<h2 class="display-3 text-center my-4">Create Group</h2>
<form class="text-center bg-primary " method="post" action="{{ route('group.update') }}">

    {{csrf_field()}}
    GroupID
    <input class="bg-info text-danger p-2"  type="number" name="GroupID"><br>
    Select Id to Assign Into Group :
    <select class="bg-info text-danger p-2" name='member[]' multiple> 
        @foreach ($users as $user)
            <option value="{{ $user->name }}">{{ $user->studentID }}</option>
            
        @endforeach
    </select>
   

    <br>
    <br>
    Enter Status:
    <select class="bg-info text-danger p-2"  name="Status">
        <option value="Official" name="Status">Official</option>
        <option value="UnOfficial" name="Status">UnOfficial</option>

    </select>
    <br>
    Enter Deadline:
    <input class="bg-info text-danger p-2"  type="text" name="Deadline" placeholder="Enter Deadline" ><br>
    JudgementalView:
    <select class="bg-info text-danger p-2"  name="JudgementalView">
        <option value="Ongoing" name="JudgementalView">On going</option>
        <option value="Registered" name="JudgementalView">Registered</option>
        <option value="Completed" name="JudgementalView">Completed</option>

    </select>
    <br>
    <input class= "btn btn-danger px-5" type="submit" name="submit">

</form>


@section('content')