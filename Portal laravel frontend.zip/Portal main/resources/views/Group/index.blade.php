@extends('layouts.app')



@section('content')

    <h1>Groups</h1>
    <table class="bg-primary" border="2" cellpadding='10' cellspacing="10">
        <tr>
            <th>
            GroupID
            </th>
            <th>
            Member
            </th>
            <th>
            Status
            </th>
            <th>
            Deadline
            </th>
            <th>
            JudgementalView
            </th>
           
        </tr>
        @foreach($info as $post)

            <tr>
                <td>{{$post->GroupID}}</td>

                <td>{{$post->Member}}</td>

                <td>{{$post->Status}}</td>
                <td>{{$post->Deadline}}</td>
                <td>{{$post->JudgementalView}}</td>
                

                <td></td>


                <td>

                    <form action="{{ route('group.destroy', $post->id)}}" method="post">
                        @csrf
                        @method('DELETE')
                        <button class="btn btn-danger" type="submit">Delete</button>
                    </form>



                </td>

                <td>

                    <form action="{{route('group.edit' ,$post->id)}}" method="post">
                        @csrf
                        @method('GET')
                        <button class="btn btn-danger" type="submit">Update</button>
                    </form>



                </td>
            </tr>
        @endforeach

        <form action="{{route('group.create' ,$post->id)}}" method="post">
            @csrf
            @method('GET')
            <button class="btn btn-danger" type="submit">Create</button>
        </form>

    </table>







@endsection