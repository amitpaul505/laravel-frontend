<h2 class="display-3 text-center my-4">Create Group</h2>
<form class="text-center bg-primary " method="post" action="<?php echo e(route('group.update')); ?>">

    <?php echo e(csrf_field()); ?>

    GroupID
    <input class="bg-info text-danger p-2"  type="number" name="GroupID"><br>
    Select Id to Assign Into Group :
    <select class="bg-info text-danger p-2" name='member[]' multiple> 
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($user->name); ?>"><?php echo e($user->studentID); ?></option>
            
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
   

    <br>
    <br>
    Enter Status:
    <select class="bg-info text-danger p-2"  name="Status">
        <option value="Official" name="Status">Official</option>
        <option value="UnOfficial" name="Status">UnOfficial</option>

    </select>
    <br>
    Enter Deadline:
    <input class="bg-info text-danger p-2"  type="text" name="Deadline" placeholder="Enter Deadline" ><br>
    JudgementalView:
    <select class="bg-info text-danger p-2"  name="JudgementalView">
        <option value="Ongoing" name="JudgementalView">On going</option>
        <option value="Registered" name="JudgementalView">Registered</option>
        <option value="Completed" name="JudgementalView">Completed</option>

    </select>
    <br>
    <input class= "btn btn-danger px-5" type="submit" name="submit">

</form>


<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>