<?php $__env->startSection('content'); ?>

    <h1>User</h1>
    <table border="1" cellpadding='5' cellspacing="0">
        <tr>
            <th>
                Name
            </th>
            <th>
                Domain Id
            </th>
            <th>
                Semester
            </th>
            <th>
                Type Id
            </th>
            <th>
                Level
            </th>
            <th>
                Description
            </th>
            <th>
                Faculty Id
            </th>
            <th>
                Status
            </th>
            <th>
                File Status
            </th>
        </tr>
        <?php $__currentLoopData = $info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <tr>
                <td><?php echo e($post->Name); ?></td>

                <td><?php echo e($post->Domain_ID); ?></td>

                <td><?php echo e($post->Semester); ?></td>
                <td><?php echo e($post->Type_ID); ?></td>
                <td><?php echo e($post->Level); ?></td>
                <td><?php echo e($post->Description); ?></td>
                <td><?php echo e($post->Faculty_ID); ?></td>
                <td><?php echo e($post->Status); ?></td>
                <td><?php echo e($post->File_Status); ?></td>

                <td></td>


                <td>

                    <form action="<?php echo e(route('research.destroy', $post->id)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button class="btn btn-danger" type="submit">Delete</button>
                    </form>



                </td>

                <td>

                    <form action="<?php echo e(route('research.edit' ,$post->id)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('GET'); ?>
                        <button class="btn btn-danger" type="submit">Update</button>
                    </form>



                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <form action="<?php echo e(route('research.create' ,$post->id)); ?>" method="post">
            <?php echo csrf_field(); ?>
            <?php echo method_field('GET'); ?>
            <button class="btn btn-danger" type="submit">Create</button>
        </form>

    </table>







<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>