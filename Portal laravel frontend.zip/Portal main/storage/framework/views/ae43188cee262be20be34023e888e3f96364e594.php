<?php $__env->startSection('content'); ?>
<body>
        
	

            <h1>User</h1>
            <table class="bg-primary" border="2" cellpadding='10' cellspacing="10">
                <tr>
                    <th>
                        Id
                    </th>
                    <th>
                        Name
                    </th>
                    <th>
                        Student ID
                    </th>
                    <th>
                        Email
                    </th>
                </tr>
                <?php $__currentLoopData = $info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr>
                    <td><?php echo e($post->user_id); ?></td>

                    <td><?php echo e($post->name); ?></td>

                    <td><?php echo e($post->studentID); ?></td>
                    <td><?php echo e($post->email); ?></td>
                    <td>
                        <?php if($post->user_id == 1): ?>
                   Admin

                    <?php else: ?>
                   User
                   <?php endif; ?>
                    </td>


                    <td>

                        <form action="<?php echo e(route('info.destroy', $post->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-danger" type="submit">Delete</button>
                        </form>

                    </td>

                    <td>

                        <form action="<?php echo e(route('info.edit' ,$post->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('GET'); ?>
                            <button class="btn btn-danger" type="submit">Update</button>
                        </form>



                    </td>

                    <td>

                  


                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <form action="<?php echo e(route('info.create' ,$post->id)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('GET'); ?>
                    <button class="btn btn-danger" type="submit">Create</button>
                </form>

            </table>

            

</body>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>