<?php $__env->startSection('content'); ?>
<body>
    <h1 class="display-3 text-center my-4">Create</h1>    
<form class="bg-primary "  method="post" action="<?php echo e(route('info.store')); ?>" >

    


    <?php echo e(csrf_field()); ?>



    <div class="form-group">
        <label for="User Type">User Type</label>
        <select class="bg-white text-danger  form-control " name="user_id">
                <label for="User Type">User Type</label>
                <option value="1" name="user_id">Admin</option>
                <option value="2" name="user_id">User</option>
        
            </select>
        </div>
    <div class="form-group">
        <label for="name">Name</label>
        <input class="bg-white text-danger p-2 form-control form-control-sm" type="text" name="name" placeholder="ENTER Name">
        <?php echo $errors->first('Name', '<p class="help-block">:message</p>'); ?>

    </div>
    <div class="form-group">
        <label for="Student Id">Enter Student Id</label>
        <input class="bg-white text-danger p-2 form-control form-control-sm" type="text" name="studentID" placeholder="ENTER Studen ID" >
        <?php echo $errors->first('UserName', '<p class="help-block">:message</p>'); ?>

    </div>
    <div class="form-group">
        <label for="email">Email</label>
        <input class="bg-white text-danger p-2 form-control form-control-sm" type="text" name="email">
        <?php echo $errors->first('email', '<p class="help-block">:message</p>'); ?>

    </div>
    <div class="form-group">
        <label for="password">Password</label>
        <input class="bg-white text-danger p-2 form-control form-control-sm" type="text" name="password" placeholder="ENTER Password" ><br></br>
        <?php echo $errors->first('Password', '<p class="help-block">:message</p>'); ?>

    </div>

    <input class="btn btn-danger btn-lg" type="submit" name="submit">

            


</form>
            <script src="js/jquery-slim.min.js"></script>
            <script src="js/popper.min.js"></script>
            <script src="js/bootstrap.min.js"></script>
            </body>


            
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>