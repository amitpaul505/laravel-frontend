<form method="post" action="<?php echo e(route('research.store')); ?> " id="1" >

    <?php echo e(csrf_field()); ?>




    <input type="text" name="Name" placeholder="ENTER Name"><br></br>
    <input type="number" name="Domain_ID" placeholder="ENTER Domain Id" ><br></br>
    <input type="text" name="Semester" placeholder="ENTER Semester" ><br></br>
    <input type="number" name="Type_ID" placeholder="ENTER Type Id" ><br></br>
    <input type="text" name="Level" placeholder="ENTER Level" ><br></br>
    <textarea name="Description" form="1">Enter Description here...</textarea>
    <input type="number" name="Faculty_ID" placeholder="ENTER Faculty Id" ><br></br>
    <input type="text" name="Status" placeholder="ENTER Status" ><br></br>
    <input type="text" name="File_Status" placeholder="ENTER File Status" ><br></br>

    <input type="submit" name="submit">

</form>


<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>